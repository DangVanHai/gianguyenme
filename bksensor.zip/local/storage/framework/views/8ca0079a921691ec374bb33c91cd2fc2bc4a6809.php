
<?php if(Session::has('quote')): ?>
<p class="alert alert-success"><?php echo e(Session::get('quote')); ?></p>
<?php endif; ?>
