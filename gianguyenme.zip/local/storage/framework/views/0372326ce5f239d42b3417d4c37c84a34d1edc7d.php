<?php if(Session::has('error')): ?>
<p class="alert alert-danger"><?php echo e(Session::get('error')); ?></p>
<?php endif; ?>
<?php if(Session::has('error_add_cate')): ?>
<p class="alert alert-danger"><?php echo e(Session::get('error_add_cate')); ?></p>
<?php endif; ?>
<?php if(Session::has('success')): ?>
<p class="alert alert-success"><?php echo e(Session::get('success')); ?></p>
<?php endif; ?>
<?php if(Session::has('comment')): ?>
<p class="alert alert-success"><?php echo e(Session::get('comment')); ?></p>
<?php endif; ?>
<?php if(Session::has('adduser')): ?>
<div class="content mt-3">
    <div class="col-sm-12">
        <div class="alert  alert-success alert-dismissible fade show" role="alert">
          <span class="badge badge-pill badge-success">Success </span><?php echo e(Session::get('adduser')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
</div>
<?php endif; ?>
<!-- lỗi thêm danh mục -->
<?php if(isset($errors)): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p class="alert alert-danger"><?php echo e($value); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
